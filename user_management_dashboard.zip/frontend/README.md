
# User Management Dashboard

## Tech Stack
- Frontend: React.js (functional components with hooks), React Router DOM, Axios, Tailwind CSS
- Backend: Node.js, Express.js, MongoDB with Mongoose
- Others: CORS enabled for frontend integration

## Setup Instructions

### Backend
1. Navigate to backend folder:
   ```bash
   cd backend
   ```
2. Install dependencies:
   ```bash
   npm install express mongoose cors dotenv
   ```
3. Create a `.env` file based on `.env.example`.
4. Start the server:
   ```bash
   node index.js
   ```

### Frontend
1. Navigate to frontend folder:
   ```bash
   cd frontend
   ```
2. Install dependencies:
   ```bash
   npm install react-router-dom axios tailwindcss
   ```
3. Start the development server:
   ```bash
   npm start
   ```

## Example Requests

Use Postman or curl to test API endpoints defined in backend.

