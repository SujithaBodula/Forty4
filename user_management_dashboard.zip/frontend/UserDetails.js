
import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import axios from 'axios';

function UserDetails() {
  const { id } = useParams();
  const [user, setUser] = useState(null);

  useEffect(() => {
    axios.get(`http://localhost:5000/users/${id}`)
      .then(res => setUser(res.data))
      .catch(err => console.error(err));
  }, [id]);

  if (!user) return <div>Loading...</div>;

  return (
    <div>
      <h2 className="font-bold text-xl mb-2">{user.name}</h2>
      <p>Email: {user.email}</p>
      <p>Phone: {user.phone}</p>
      <p>Company: {user.company}</p>
      <p>Address:</p>
      <ul className="ml-4 list-disc">
        <li>Street: {user.address.street}</li>
        <li>City: {user.address.city}</li>
        <li>Zipcode: {user.address.zipcode}</li>
        <li>Geo: Lat {user.address.geo.lat}, Lng {user.address.geo.lng}</li>
      </ul>
      <Link to="/" className="text-blue-500 mt-4 inline-block">Back to Dashboard</Link>
    </div>
  );
}

export default UserDetails;
