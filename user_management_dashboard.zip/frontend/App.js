
import React from 'react';
import { Routes, Route, Link } from 'react-router-dom';
import Dashboard from './Dashboard';
import UserDetails from './UserDetails';

function App() {
  return (
    <div className="container mx-auto p-4">
      <nav className="mb-4">
        <Link to="/" className="text-blue-500">Dashboard</Link>
      </nav>
      <Routes>
        <Route path="/" element={<Dashboard />} />
        <Route path="/user/:id" element={<UserDetails />} />
      </Routes>
    </div>
  );
}

export default App;
